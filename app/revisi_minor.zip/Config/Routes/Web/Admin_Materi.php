<?php

$routes->get('/Admin/Materi/','\App\Controllers\Admin\Materi::index');
$routes->get('/Admin/Materi/New','\App\Controllers\Admin\Materi::new');
$routes->get('/Admin/Materi/Show/(:num)','\App\Controllers\Admin\Materi::show');
$routes->get('/Admin/Materi/Edit/(:num)','\App\Controllers\Admin\Materi::edit');
$routes->post('/Admin/Materi/Store','\App\Controllers\Admin\Materi::store');

