<?php

$routes->get('/Admin/Program/','\App\Controllers\Admin\Program::index');
$routes->get('/Admin/Program/New','\App\Controllers\Admin\Program::new');
$routes->get('/Admin/Program/Show/(:num)','\App\Controllers\Admin\Program::show');
$routes->get('/Admin/Program/Edit/(:num)','\App\Controllers\Admin\Program::edit');
$routes->post('/Admin/Program/Store','\App\Controllers\Admin\Program::store');

