<?php

$routes->get('/Admin/Soaltryout/session/(:any)','\App\Controllers\Admin\Soaltryout::session/$1');

$routes->group('/Admin/Soaltryout',['filter'=>'tryoutAdmin','namespace'=>'\App\Controllers\Admin'],function($routes){

  $routes->get('/','Soaltryout::index');
  $routes->get('/New','Soaltryout::new');
  $routes->get('/Show/(:num)','Soaltryout::show');
  $routes->get('/Edit/(:num)','Soaltryout::edit');
  $routes->post('/Store','Soaltryout::store');

});


