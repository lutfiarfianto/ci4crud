<?php

$routes->get('/Admin/Matakuliah/','\App\Controllers\Admin\Matakuliah::index');
$routes->get('/Admin/Matakuliah/New','\App\Controllers\Admin\Matakuliah::new');
$routes->get('/Admin/Matakuliah/Show/(:num)','\App\Controllers\Admin\Matakuliah::show');
$routes->get('/Admin/Matakuliah/Edit/(:num)','\App\Controllers\Admin\Matakuliah::edit');
$routes->post('/Admin/Matakuliah/Store','\App\Controllers\Admin\Matakuliah::store');

