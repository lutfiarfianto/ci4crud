<?php


$routes->cli('fakeInsert', '\Myclass\Controllers\Fakery::run');

$routes->cli('xtable','\Myclass\Controllers\Xtable::run');