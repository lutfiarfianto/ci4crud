<?php

/**
 * **Row Number**
 * 
 * ---
 * 
 * params:
 * 
 * - $paging_data = {current_page: ?, per_page: ?}
 * - $idx = row index 
 * 
 */
function row_num($per_page,$idx)
{
  $pager = \Config\Services::pager();
  $current_page = $pager->getCurrentPage();
  echo ($current_page-1)*$per_page+$idx+1;
}


function force_redirect($url)
{
  header('Location: '.$url);
  exit;
}